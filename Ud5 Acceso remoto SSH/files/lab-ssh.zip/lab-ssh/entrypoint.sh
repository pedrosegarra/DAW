#!/bin/sh
set -e

# Claves de host: se generan si no existen (un contenedor recreado tendrá claves NUEVAS)
ssh-keygen -A >/dev/null

# Clave pública autorizada, montada desde ./claves del anfitrión
install -m 600 -o alumno -g alumno /claves/authorized_keys /home/alumno/.ssh/authorized_keys

# Nodo "web": un panel interno que solo escucha en 127.0.0.1:8000 (para el túnel)
if [ -n "$WEB_DEMO" ]; then
    mkdir -p /srv/web
    echo "<h1>Panel interno de $(hostname)</h1><p>Solo accesible desde 127.0.0.1</p>" > /srv/web/index.html
    runuser -u nobody -- python3 -m http.server 8000 --bind 127.0.0.1 --directory /srv/web &
fi

# sshd en primer plano, con el registro en la salida de error (docker compose logs)
exec /usr/sbin/sshd -D -e
